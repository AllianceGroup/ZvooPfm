'use strict';

$(function () {

    // moment.js default language
    moment.locale('en')

    angular.bootstrap(document, ['app']);

});
