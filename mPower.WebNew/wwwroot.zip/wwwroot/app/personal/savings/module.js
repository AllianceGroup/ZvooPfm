"use strict";

angular.module('app.personal')

    .config(function ($stateProvider) {
        $stateProvider
            .state('app.personal.savings', {
                url: '/savings',
                views: {
                    "content@app": {
                        controller: 'savingsController',
                        controllerAs: 'savingsCtrl',
                        templateUrl: 'app/personal/savings/savings.tpl.html'
                    }
                },
                data:{
                    title: 'savings'
                },
             

            });
    });