'use strict';

angular.module('app.personal').controller('savingsController',
    function savingsControllers($rootScope) {
        var ctrl = this;
      
    });