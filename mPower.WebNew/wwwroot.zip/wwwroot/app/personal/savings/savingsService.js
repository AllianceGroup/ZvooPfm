'use strict';

angular.module('app.personal').service('savingsService', ['http', function (http) {
   
}]);