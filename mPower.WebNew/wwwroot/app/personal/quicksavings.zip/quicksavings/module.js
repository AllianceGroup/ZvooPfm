"use strict";

angular.module('app.personal').config(function ($stateProvider) {
        $stateProvider
            .state('app.personal.quicksavings', {
                url: '/quicksavings',
                views: {
                    "content@app": {
                        controller: 'quickSavingsController',
                        controllerAs: 'savingsCtrl',
                        templateUrl: 'app/personal/quicksavings/quickSavings.tpl.html'
                       
                    },
                },
                data: {
                    title: 'QuickSavings'
                },
                resolve: {
                    transactionsPage: function () {
                        return "app.personal.quicksavings";
                    }
                    //TestingApiResult: function (savingsService) {
                    //    return savingsService.GetApiTesting();
                      
                    //},
                }
               
            })
    });

