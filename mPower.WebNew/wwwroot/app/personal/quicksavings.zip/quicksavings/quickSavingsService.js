﻿'use strict';

angular.module('app.personal').service('quickSavingsService', ['http', function (http) {

    //this.GetApiTesting = function () {
    //    var url = '/Authentication/GetApiTesting';
    //    return http.get(url);
   
    //};

    this.postapiurl = function (data) {
        var url = '/debtelimination/NewDebt';
        return http.post(url, data);
    };

   
}]);