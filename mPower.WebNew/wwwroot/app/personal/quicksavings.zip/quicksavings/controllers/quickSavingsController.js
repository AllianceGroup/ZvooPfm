﻿'use strict';

angular.module('app.personal').controller('quickSavingsController', ['quickSavingsService', 'model', '$uibModal',
    function (quickSavingsService, model, $uibModal) {
        var ctrl = this;
        ctrl.actionFunction = model.actionFunction;



        //ctrl.callpostapi = function () {
        //    ctrl.errors = [];
        //    quickSavingsService.postapiurl(model).then(function () {
        //        model.AccountLabels.Selected = true;
        //        $.smallBox({
        //            title: "Success",
        //            content: "Account added",
        //            color: "#739e73",
        //            timeout: 4000
        //        });

        //    }, function (errors) {
        //        for (var key in errors) {
        //            if (errors.hasOwnProperty(key)) {
        //                for (var i = 0; i < errors[key].length; i++) {
        //                    ctrl.errors.push(errors[key][i]);
        //                }
        //            }
        //        }
        //    });
        //};

        ctrl.callpostapi = function () {
            ctrl.actionFunction(ctrl.data).then(function (data) {
               
            }, function (errors) {
                ctrl.errors = _.reduce(errors, function (result, arr) {
                    return result.concat(arr);
                }, []);
            });
        };


        ctrl.openmodal = function () {
            $uibModal.open({
                templateUrl: "app/personal/quicksavings/views/quickSavingModal.tpl.html",
                //controller: 'ChoiceAccountController',
                //controllerAs: 'choiceAccountCtrl'
            });
        };


    }]);

//, TestingApiResult || ctrl.ApiResultData = TestingApiResult;